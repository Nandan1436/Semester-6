package com.example;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

public class AuthManagerTest {

    @Mock
    private HashLibrary hashLibrary;

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private AuthManager authManager;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void loginSucceedsWithCorrectCredentials() throws Exception {
        when(userRepository.findByEmail("nandan@gmail.com"))
                .thenReturn(new User("nandan@gmail.com", "123@#$"));
        when(hashLibrary.hash("123456")).thenReturn("123@#$");

        assertTrue(authManager.login("nandan@gmail.com", "123456"));
    }

    @Test(expected = Exception.class)
    public void loginThrowsExceptionForNonExistingUser() throws Exception {
        when(userRepository.findByEmail("nonexistent@gmail.com"))
                .thenThrow(new Exception("User not found"));

        authManager.login("nonexistent@gmail.com", "anyPassword");
    }

    @Test
    public void loginFailsWithWrongPassword() throws Exception {
        when(userRepository.findByEmail("nandan@gmail.com"))
                .thenReturn(new User("nandan@gmail.com", "123@#$"));
        when(hashLibrary.hash("wrongPassword")).thenReturn("wrongHash");

        assertFalse(authManager.login("nandan@gmail.com", "wrongPassword"));
    }
}
