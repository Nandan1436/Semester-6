package com.example;

public class UserRepository {
    public User findByEmail(String email) throws Exception {
        if(email.contains("asdfs"))throw new Exception();
        return new User("Nandan","123456");
    }
}
