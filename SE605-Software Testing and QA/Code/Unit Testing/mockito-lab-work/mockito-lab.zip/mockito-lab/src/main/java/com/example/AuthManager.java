package com.example;

public class AuthManager {
    public boolean login(String email, String password){
        UserRepository userRepository = new UserRepository();
        HashLibrary hashLibrary = new HashLibrary();
        try{
            User user = userRepository.findByEmail(email);
            if (hashLibrary.hash(password) == user.getPassword()) {
                return true;
            } else return false;
        }catch(Exception exception){
            return false;
        }

    }
}
