package com.example;

public class HashLibrary {
    public String hash(String password){
        if(password=="123456")return "123@#$";
        else return "1";
    }
}
